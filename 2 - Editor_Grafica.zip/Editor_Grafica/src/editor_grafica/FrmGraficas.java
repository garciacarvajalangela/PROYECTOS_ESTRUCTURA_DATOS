package editor_grafica;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JOptionPane;

public class FrmGraficas extends javax.swing.JFrame {

    boolean inicioTrazo;
    int x1, y1;
    Dibujo d;

    boolean seleccionando;

    public FrmGraficas() {
        initComponents();
        inicioTrazo = false;
        d = new Dibujo();
        seleccionando = false;

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlGraficas = new javax.swing.JPanel();
        cmbTrazo = new javax.swing.JComboBox<>();
        btnAbrir = new javax.swing.JButton();
        btnSeleccionar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlGraficas.setBackground(new java.awt.Color(0, 102, 255));
        pnlGraficas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pnlGraficasMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlGraficasLayout = new javax.swing.GroupLayout(pnlGraficas);
        pnlGraficas.setLayout(pnlGraficasLayout);
        pnlGraficasLayout.setHorizontalGroup(
            pnlGraficasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        pnlGraficasLayout.setVerticalGroup(
            pnlGraficasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 378, Short.MAX_VALUE)
        );

        cmbTrazo.setFont(new java.awt.Font("MS Reference Sans Serif", 0, 24)); // NOI18N
        cmbTrazo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "Linea", "Rectangulo", "Circulo", "" }));
        cmbTrazo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        cmbTrazo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbTrazoActionPerformed(evt);
            }
        });

        btnAbrir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/Abrir.png"))); // NOI18N
        btnAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbrirActionPerformed(evt);
            }
        });

        btnSeleccionar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/Seleccionar.png"))); // NOI18N

        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/Guardar.png"))); // NOI18N
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(cmbTrazo, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSeleccionar, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnAbrir)
                .addGap(18, 18, 18)
                .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(206, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlGraficas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnAbrir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSeleccionar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnGuardar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(cmbTrazo, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(12, 12, 12)
                .addComponent(pnlGraficas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void pnlGraficasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlGraficasMouseClicked

        int x = evt.getX();
        int y = evt.getY();
        Graphics g = pnlGraficas.getGraphics();

        if (!btnSeleccionar.isSelected()) {

            if (!inicioTrazo) {
                inicioTrazo = true;
                x1 = x;
                y1 = y;
            } else {
                inicioTrazo = false;

                
                int ancho = x - x1 + 1;
                if (x < x1) {
                    ancho = -ancho;
                    x1 = x;
                }

                int alto = y - y1;
                if (y < y1) {
                    alto = -alto;
                    y1 = y;
                }

                switch (cmbTrazo.getSelectedIndex()) {
                    case 0:
                        break;
                    case 1:
                        g.setColor(Color.BLACK);
                        g.drawLine(x1, y1, x, y);
                        break;
                    case 2:
                        g.setColor(Color.BLACK);
                        g.drawRect(x1, y1, ancho, alto);
                        break;
                    case 3:
                        g.setColor(Color.BLACK);
                        g.drawOval(x1, y1, ancho, alto);
                        break;

                }
            }

        } else {
            Primitiva p = d.buscar(x, y);
            if (p != null) {
                d.dibujar(pnlGraficas);
                int x1 = p.getX1() > p.getX2() ? p.getX2() : p.getX1();
                int y1 = p.getY1() > p.getY2() ? p.getY2() : p.getY1();
                g.setColor(Color.red);
                g.fillRect(x1, y1, p.getAncho(), p.getAlto());
            }
        }

    }//GEN-LAST:event_pnlGraficasMouseClicked

    private void btnAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbrirActionPerformed
        String nombreArchivo = Archivo.elegirArchivo("Seleccionar archivo", "Abrir", "*.*", "Todos los archivos");
        if (nombreArchivo.length() > 0) {
            d.desdeArchivo(nombreArchivo);
            d.dibujar(pnlGraficas);
        }
    }//GEN-LAST:event_btnAbrirActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
//      //  String nombreArchivo = Archivo.guardarArchivo(nombreArchivo, lineas); 
//        
//     //   if (nombreArchivo !=null && lineas != null) {
//            d.guardar(nombreArchivo);
//            JOptionPane.showMessageDialog(null, "Datos guardados exitosamente");
//        } else {
//            JOptionPane.showMessageDialog(null, "No se pudieron guardar los cambios");
//        }
//
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void cmbTrazoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbTrazoActionPerformed


    }//GEN-LAST:event_cmbTrazoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmGraficas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmGraficas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmGraficas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmGraficas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmGraficas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAbrir;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnSeleccionar;
    private javax.swing.JComboBox<String> cmbTrazo;
    private javax.swing.JPanel pnlGraficas;
    // End of variables declaration//GEN-END:variables
}
