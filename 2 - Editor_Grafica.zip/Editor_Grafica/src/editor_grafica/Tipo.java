
package editor_grafica;

public enum Tipo {
    LINEA,
    CIRCULO,
    RECTANGULO,
     
}
