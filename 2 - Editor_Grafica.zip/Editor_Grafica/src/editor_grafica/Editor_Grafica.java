
package editor_grafica;

public class Editor_Grafica {

    public static void main(String[] args) {
            new FrmGraficas().setVisible(true);
    }
    
}
