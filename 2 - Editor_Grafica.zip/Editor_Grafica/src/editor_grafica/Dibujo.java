package editor_grafica;

import java.awt.Color;
import java.awt.Graphics;
import java.io.BufferedReader;
import java.io.IOException;
import javax.swing.JPanel;

public class Dibujo {

    private Primitiva cabeza;

    public Dibujo() {
        cabeza = null;
    }

    public void agregar(Primitiva p) {
        if (cabeza == null) {
            cabeza = p;
        } else {
            Primitiva apuntador = cabeza;
            while (apuntador.siguiente != null) {
                apuntador = apuntador.siguiente;
            }
            apuntador.siguiente = p;
        }
        p.siguiente = null;
    }

    public void desdeArchivo(String nombreArchivo) {
        BufferedReader br = Archivo.abrirArchivo(nombreArchivo);

        cabeza = null;
        try {
            String linea = br.readLine();
            while (linea != null) {
                String[] datos = linea.split(";");
                Tipo tipo = null;

                for (int i = 0; i < Tipo.values().length; i++) {
                    if (Tipo.values()[i].toString().equals(datos[0])) {
                        tipo = Tipo.values()[i];
                    }
                }
                int x1 = Integer.parseInt(datos[1]);
                int y1 = Integer.parseInt(datos[2]);
                int x2 = Integer.parseInt(datos[3]);
                int y2 = Integer.parseInt(datos[4]);
                Primitiva p = new Primitiva(x1, y1, x2, y2, tipo);
                agregar(p);
                linea = br.readLine();
            }
        } catch (IOException ex) {

        }
    }

    public void dibujar(JPanel pnl) {
        Graphics g = pnl.getGraphics();
        g.setColor(Color.pink);
        g.fillRect(0, 0, pnl.getWidth(), pnl.getHeight());
        Primitiva apuntador = cabeza;
        while (apuntador != null) {
            Primitiva.dibujar(pnl, apuntador);
            apuntador = apuntador.siguiente;

        }
    }

    public Primitiva buscar(int x, int y) {
        Primitiva apuntador = cabeza;
        while (apuntador != null) {
            if (apuntador.contiene(x, y)) {

            }

        }
        return apuntador;
    }

    public int obtenerLongitud() {
        int totalNodos = 0;
        Primitiva apuntador = cabeza;
        while (apuntador != null) {
            totalNodos++;
            apuntador = apuntador.siguiente;
        }
        return totalNodos;
    }

    public boolean guardar(String nombreArchivo) {
        int totalLineas = obtenerLongitud();
        if (totalLineas > 0) {
            String[] lineas = new String[totalLineas];
            Primitiva apuntador = cabeza;
            int i = 0;
            while (apuntador != null) {
                lineas[i] = (apuntador.getTipo() + ";"
                        + (apuntador.getX1() + "; ")
                        + (apuntador.getY1() + "; ")
                        + (apuntador.getX2()) + "; "
                        + (apuntador.getY2() + ";"));
                apuntador = apuntador.siguiente;
                i++;
            }
            return Archivo.guardarArchivo(nombreArchivo, lineas);
        }
        return false;
    }

}
