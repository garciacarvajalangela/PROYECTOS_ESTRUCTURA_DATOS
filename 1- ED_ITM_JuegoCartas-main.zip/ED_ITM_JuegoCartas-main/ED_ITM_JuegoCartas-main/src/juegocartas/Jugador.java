package juegocartas;

import java.util.Random;
import javax.swing.JPanel;

public class Jugador {

    private int TOTAL_CARTAS = 10;
    private int DISTANCIA = 40;
    private int MARGEN = 5;
    
    String[] nombreNoPuntuar = new String[NombreCarta.values().length];
    
    private Carta[] cartas = new Carta[TOTAL_CARTAS];
    private Random r = new Random();

    public void repartir() {
        for (int i = 0; i < TOTAL_CARTAS; i++) {
            cartas[i] = new Carta(r);
        }
    }

    public void mostrar(JPanel pnl) {
        pnl.removeAll();
        for (int i = 0; i < cartas.length; i++) {
            cartas[i].mostrar(pnl, MARGEN + TOTAL_CARTAS * DISTANCIA - i * DISTANCIA, MARGEN);
        }
        pnl.repaint();
    }

    public String getGrupos() {
        String mensaje = "No hay grupos";
        int[] contadores = new int[NombreCarta.values().length];

        for (int i = 0; i < cartas.length; i++) {
            contadores[cartas[i].getNombre().ordinal()]++;
        }

        int totalGrupos = 0;
        for (int i = 0; i < contadores.length; i++) {
            if (contadores[i] >= 2) {
                totalGrupos++;
            }
        }
        if (totalGrupos > 0) {
            mensaje = "Los grupos encontrados fueron:\n";
            for (int i = 0; i < contadores.length; i++) {
                if (contadores[i] >= 2) {
                    mensaje += Grupo.values()[contadores[i]] + " de " + NombreCarta.values()[i] + "\n";
                }
            }
        }

        return mensaje;
    }

    public void ordenar() {
        for (int i = 0; i < cartas.length - 1; i++) {
            for (int j = i + 1; j < cartas.length; j++) {
                if (cartas[i].getIndice() > cartas[j].getIndice()) {
                    Carta ct = cartas[i];
                    cartas[i] = cartas[j];
                    cartas[j] = ct;
                }
            }
        }
    }

    public String getPinta() {
        String mensaje = "No hay grupos";
        int[] escalera = new int[NombreCarta.values().length];

        for (int i = 0; i < cartas.length; i++) {
            escalera[cartas[i].getPinta().ordinal()]++;
        }

        int totalEscaleras = 0;
        for (int i = 0; i < escalera.length; i++) {
            if (escalera[i] <= 13) {//&& escalera[cartas[i].NumCarta()]< escalera[cartas[i+1].NumCarta()]&& escalera[cartas[i+1].NumCarta()]< escalera[cartas[i+2].NumCarta()]) {
                Pinta.TREBOL.toString();
              //  totalEscaleras++;
            } else {
                 if (escalera[i] <= 26){// && escalera[cartas[i].NumCarta()]< escalera[cartas[i+1].NumCarta()]&& escalera[cartas[i+1].NumCarta()]< escalera[cartas[i+2].NumCarta()]) {
                    Pinta.PICA.toString();
                //    totalEscaleras++;
                } else {
                     if (escalera[i] <= 39){// && escalera[cartas[i].NumCarta()]< escalera[cartas[i+1].NumCarta()]&& escalera[cartas[i+1].NumCarta()]< escalera[cartas[i+2].NumCarta()]) {
                        Pinta.CORAZON.toString();
                  //      totalEscaleras++;
                    } else {
                         if (escalera[i]<= 52){ //&& escalera[cartas[i].NumCarta()]< escalera[cartas[i+1].NumCarta()]&& escalera[cartas[i+1].NumCarta()]< escalera[cartas[i+2].NumCarta()]) {
                    //        Pinta.DIAMANTE.toString();
                            totalEscaleras++;
                        }
                    }
                }
            }
        }
       
            mensaje = "Las escaleras encontradas fueron:\n";
            for (int i = 0; i < escalera.length; i++) {
                if (escalera[i] >= 3) {
                    mensaje += Grupo.values()[escalera[i]] + " de " + Pinta.values()[i] + "\n";
                }
            }
    

        return mensaje;
    }
    
    public int getPuntaje() {
    int puntaje = 0; // Inicializamos el puntaje en 0.

    // Iteramos a través de las cartas en la mano del jugador.
    for (int i = 0; i < cartas.length; i++) {
        NombreCarta nombre = cartas[i].getNombre(); // Obtenemos el nombre de la carta.

        // Verificamos si la carta es AS, Jack, Queen, o King.
        if (nombre == NombreCarta.AS || nombre == NombreCarta.JACK || nombre == NombreCarta.QUEEN || nombre == NombreCarta.KING) {
            puntaje += 10; // Si es una de estas cartas, sumamos 10 al puntaje.
        } else {
            puntaje += nombre.ordinal() + 1; // Si no, sumamos el valor numérico de la carta.
            // El ordinal()+1 corresponde al valor numérico de la carta.
        }
    }

    return puntaje; // Devolvemos el puntaje total del jugador.
}
}

//        for (y = 0; y < cartas.length - 1; y++) {
//            if (cartas[y].NumCarta() <= 13 && cartas[y].NumCarta() < cartas[y + 1].NumCarta() && cartas[y + 1].NumCarta() < cartas[y + 2].NumCarta()) {
//                mensaje += "terna de" + (Pinta.TREBOL.toString());
//
//            } else if (cartas[y].NumCarta() <= 26 && cartas[y].NumCarta() < cartas[y + 1].NumCarta() && cartas[y + 1].NumCarta() < cartas[y + 2].NumCarta()) {
//                mensaje += "terna de " + (Pinta.PICA.toString());
//
//            } else if (cartas[y].NumCarta() <= 39 && cartas[y].NumCarta() < cartas[y + 1].NumCarta() && cartas[y + 1].NumCarta() < cartas[y + 2].NumCarta()) {
//                mensaje += "terna de " + Pinta.CORAZON.toString();
//
//            } else if (cartas[y].NumCarta() <= 52 && cartas[y].NumCarta() < cartas[y + 1].NumCarta() && cartas[y + 1].NumCarta() < cartas[y + 2].NumCarta()) {
//                
//                    mensaje += "terna de " + Pinta.DIAMANTE.toString();
//                }else{
//                        mensaje += "No hay Escalera por pinta";
//                        }
//                
//                
//
//            }
//        return mensaje;    
//        }

