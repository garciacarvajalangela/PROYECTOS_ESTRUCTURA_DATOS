package polinomios;

public class Polinomios {
    
    public static void main(String[] args) {
        new FrmPolinomios().setVisible(true);
    }
    
}
